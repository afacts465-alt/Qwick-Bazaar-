import 'package:flutter/material.dart';

void main() => runApp(const QwickBazaar());

class Product {
  final String name, category;
  final int price;
  final IconData icon;
  const Product(this.name, this.category, this.price, this.icon);
}

const products = [
  Product('Smartphone Pro', 'Mobiles', 12999, Icons.smartphone),
  Product('Wireless Earbuds', 'Electronics', 1499, Icons.headphones),
  Product('Smart Watch', 'Electronics', 2499, Icons.watch),
  Product('Running Shoes', 'Fashion', 1999, Icons.directions_run),
  Product('Travel Backpack', 'Fashion', 999, Icons.backpack),
  Product('Table Lamp', 'Home', 799, Icons.light),
  Product('Bluetooth Speaker', 'Electronics', 1799, Icons.speaker),
  Product('Cotton T-Shirt', 'Fashion', 599, Icons.checkroom),
];

class QwickBazaar extends StatelessWidget {
  const QwickBazaar({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Qwick Bazaar',
      theme: ThemeData(
        useMaterial3: true,
        colorSchemeSeed: Colors.blue,
        scaffoldBackgroundColor: const Color(0xfff6f8fb),
      ),
      home: const MainScreen(),
    );
  }
}

class MainScreen extends StatefulWidget {
  const MainScreen({super.key});
  @override
  State<MainScreen> createState() => _MainScreenState();
}

class _MainScreenState extends State<MainScreen> {
  int index = 0;
  final cart = <Product>[];

  void add(Product p) {
    setState(() => cart.add(p));
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('${p.name} cart mein add ho gaya')),
    );
  }

  @override
  Widget build(BuildContext context) {
    final pages = [
      HomePage(onAdd: add),
      CartPage(cart: cart, onRemove: (p) => setState(() => cart.remove(p))),
      const OrdersPage(),
      const ProfilePage(),
    ];
    return Scaffold(
      appBar: AppBar(
        title: const Text('QB  Qwick Bazaar',
            style: TextStyle(fontWeight: FontWeight.w800)),
        actions: [
          IconButton(onPressed: () {}, icon: const Icon(Icons.notifications_none)),
        ],
      ),
      body: pages[index],
      bottomNavigationBar: NavigationBar(
        selectedIndex: index,
        onDestinationSelected: (v) => setState(() => index = v),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'Home'),
          NavigationDestination(icon: Icon(Icons.shopping_cart_outlined), selectedIcon: Icon(Icons.shopping_cart), label: 'Cart'),
          NavigationDestination(icon: Icon(Icons.receipt_long_outlined), selectedIcon: Icon(Icons.receipt_long), label: 'Orders'),
          NavigationDestination(icon: Icon(Icons.person_outline), selectedIcon: Icon(Icons.person), label: 'Profile'),
        ],
      ),
    );
  }
}

class HomePage extends StatefulWidget {
  final void Function(Product) onAdd;
  const HomePage({super.key, required this.onAdd});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  String query = '';
  String category = 'All';

  @override
  Widget build(BuildContext context) {
    final shown = products.where((p) =>
      (category == 'All' || p.category == category) &&
      p.name.toLowerCase().contains(query.toLowerCase())
    ).toList();

    return CustomScrollView(
      slivers: [
        SliverToBoxAdapter(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 12),
            child: TextField(
              onChanged: (v) => setState(() => query = v),
              decoration: InputDecoration(
                hintText: 'Products search karein...',
                prefixIcon: const Icon(Icons.search),
                filled: true, fillColor: Colors.white,
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(15),
                  borderSide: BorderSide.none,
                ),
              ),
            ),
          ),
        ),
        SliverToBoxAdapter(child: _Banner()),
        const SliverToBoxAdapter(
          child: Padding(
            padding: EdgeInsets.fromLTRB(16, 20, 16, 10),
            child: Text('Categories',
                style: TextStyle(fontSize: 21, fontWeight: FontWeight.bold)),
          ),
        ),
        SliverToBoxAdapter(
          child: SizedBox(
            height: 95,
            child: ListView(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              scrollDirection: Axis.horizontal,
              children: [
                _Cat('All', Icons.apps, category, (v) => setState(() => category = v)),
                _Cat('Mobiles', Icons.smartphone, category, (v) => setState(() => category = v)),
                _Cat('Fashion', Icons.checkroom, category, (v) => setState(() => category = v)),
                _Cat('Electronics', Icons.devices, category, (v) => setState(() => category = v)),
                _Cat('Home', Icons.home_outlined, category, (v) => setState(() => category = v)),
              ],
            ),
          ),
        ),
        const SliverToBoxAdapter(
          child: Padding(
            padding: EdgeInsets.fromLTRB(16, 18, 16, 10),
            child: Text('Popular Products',
                style: TextStyle(fontSize: 21, fontWeight: FontWeight.bold)),
          ),
        ),
        SliverPadding(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          sliver: SliverGrid(
            delegate: SliverChildBuilderDelegate(
              (_, i) => ProductCard(product: shown[i], onAdd: widget.onAdd),
              childCount: shown.length,
            ),
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 2, crossAxisSpacing: 12, mainAxisSpacing: 12,
              childAspectRatio: .66,
            ),
          ),
        ),
        const SliverToBoxAdapter(child: SizedBox(height: 20)),
      ],
    );
  }
}

class _Banner extends StatelessWidget {
  @override
  Widget build(BuildContext context) => Container(
    margin: const EdgeInsets.symmetric(horizontal: 16),
    padding: const EdgeInsets.all(20),
    decoration: BoxDecoration(
      borderRadius: BorderRadius.circular(20),
      gradient: const LinearGradient(
        colors: [Color(0xff1261d6), Color(0xff173c8f)],
      ),
    ),
    child: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text('QB', style: TextStyle(color: Colors.white, fontSize: 30, fontWeight: FontWeight.w900)),
      SizedBox(height: 4),
      Text('Qwick Bazaar', style: TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.bold)),
      SizedBox(height: 6),
      Text('Sab Kuch, Ek Hi Jagah', style: TextStyle(color: Colors.white, fontSize: 15)),
    ]),
  );
}

Widget _Cat(String name, IconData icon, String selected, void Function(String) onTap) =>
  GestureDetector(
    onTap: () => onTap(name),
    child: Container(
      width: 84, margin: const EdgeInsets.only(right: 10),
      child: Column(children: [
        CircleAvatar(
          radius: 29,
          backgroundColor: selected == name ? Colors.blue : Colors.white,
          child: Icon(icon, color: selected == name ? Colors.white : Colors.black87),
        ),
        const SizedBox(height: 7),
        Text(name, overflow: TextOverflow.ellipsis),
      ]),
    ),
  );

class ProductCard extends StatelessWidget {
  final Product product;
  final void Function(Product) onAdd;
  const ProductCard({super.key, required this.product, required this.onAdd});

  @override
  Widget build(BuildContext context) => Card(
    clipBehavior: Clip.antiAlias,
    child: InkWell(
      onTap: () => Navigator.push(context,
        MaterialPageRoute(builder: (_) => ProductPage(product: product, onAdd: onAdd))),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Expanded(
          child: Container(
            width: double.infinity,
            color: Colors.blue.shade50,
            child: Icon(product.icon, size: 70),
          ),
        ),
        Padding(
          padding: const EdgeInsets.all(10),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(product.name, maxLines: 2, overflow: TextOverflow.ellipsis,
              style: const TextStyle(fontWeight: FontWeight.w700)),
            const SizedBox(height: 4),
            Text('₹${product.price}', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 7),
            SizedBox(width: double.infinity,
              child: FilledButton(onPressed: () => onAdd(product), child: const Text('Add to Cart'))),
          ]),
        ),
      ]),
    ),
  );
}

class ProductPage extends StatelessWidget {
  final Product product;
  final void Function(Product) onAdd;
  const ProductPage({super.key, required this.product, required this.onAdd});

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Product Details')),
    body: ListView(padding: const EdgeInsets.all(16), children: [
      Container(height: 280, decoration: BoxDecoration(
        color: Colors.blue.shade50, borderRadius: BorderRadius.circular(20)),
        child: Icon(product.icon, size: 130)),
      const SizedBox(height: 20),
      Text(product.name, style: const TextStyle(fontSize: 26, fontWeight: FontWeight.bold)),
      const SizedBox(height: 8),
      Text('₹${product.price}', style: const TextStyle(fontSize: 25, fontWeight: FontWeight.bold)),
      const SizedBox(height: 12),
      const Text('4.3 ★  |  1,245 ratings'),
      const SizedBox(height: 24),
      const Text('Product Description', style: TextStyle(fontSize: 19, fontWeight: FontWeight.bold)),
      const SizedBox(height: 8),
      const Text('Achhi quality ka product. Real product data backend connect hone ke baad yahan automatically aayega.'),
      const SizedBox(height: 30),
      FilledButton.icon(
        onPressed: () { onAdd(product); Navigator.pop(context); },
        icon: const Icon(Icons.shopping_cart), label: const Text('Add to Cart')),
    ]),
  );
}

class CartPage extends StatelessWidget {
  final List<Product> cart;
  final void Function(Product) onRemove;
  const CartPage({super.key, required this.cart, required this.onRemove});

  @override
  Widget build(BuildContext context) {
    if (cart.isEmpty) return const Center(child: Column(
      mainAxisSize: MainAxisSize.min, children: [
        Icon(Icons.shopping_cart_outlined, size: 80),
        SizedBox(height: 12), Text('Cart abhi empty hai', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
      ]));
    final total = cart.fold<int>(0, (s, p) => s + p.price);
    return Column(children: [
      Expanded(child: ListView.builder(
        padding: const EdgeInsets.all(12), itemCount: cart.length,
        itemBuilder: (_, i) => Card(child: ListTile(
          leading: CircleAvatar(child: Icon(cart[i].icon)),
          title: Text(cart[i].name), subtitle: Text('₹${cart[i].price}'),
          trailing: IconButton(icon: const Icon(Icons.delete_outline), onPressed: () => onRemove(cart[i])),
        )))),
      Container(padding: const EdgeInsets.all(16), color: Colors.white,
        child: SafeArea(top: false, child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text('Total ₹$total', style: const TextStyle(fontSize: 19, fontWeight: FontWeight.bold)),
            FilledButton(onPressed: () {}, child: const Text('Checkout')),
          ],
        ))),
    ]);
  }
}

class OrdersPage extends StatelessWidget {
  const OrdersPage({super.key});
  @override
  Widget build(BuildContext context) => const Center(child: Column(
    mainAxisSize: MainAxisSize.min, children: [
      Icon(Icons.receipt_long_outlined, size: 75),
      SizedBox(height: 12), Text('Abhi koi order nahi hai', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
    ]));
}

class ProfilePage extends StatelessWidget {
  const ProfilePage({super.key});
  @override
  Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(16), children: [
    const CircleAvatar(radius: 45, child: Icon(Icons.person, size: 50)),
    const SizedBox(height: 10),
    const Center(child: Text('Guest User', style: TextStyle(fontSize: 21, fontWeight: FontWeight.bold))),
    const SizedBox(height: 22),
    Card(child: ListTile(leading: const Icon(Icons.login), title: const Text('Login / Register'), onTap: () {})),
    Card(child: ListTile(leading: const Icon(Icons.location_on_outlined), title: const Text('My Addresses'), onTap: () {})),
    Card(child: ListTile(leading: const Icon(Icons.favorite_border), title: const Text('Wishlist'), onTap: () {})),
    Card(child: ListTile(leading: const Icon(Icons.settings_outlined), title: const Text('Settings'), onTap: () {})),
  ]);
}
