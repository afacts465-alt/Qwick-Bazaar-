# QB — Qwick Bazaar MVP

Phone-friendly Flutter starter for the Qwick Bazaar e-commerce app.

## Included
- QB / Qwick Bazaar branding
- Home screen
- Search
- Category filtering
- Product cards
- Product details
- Cart
- Orders screen
- Profile screen

## Next production modules
Authentication, PostgreSQL/API backend, real product images, seller dashboard, admin dashboard, address/checkout, payment gateway, order tracking and notifications.

## Run
flutter pub get
flutter run

## Build the APK from a phone

This project includes a GitHub Actions workflow. After uploading the project files to a GitHub repository, open the **Actions** tab and run **Build Qwick Bazaar APK**. The workflow creates the Android project files, builds a release APK, and uploads the APK as an artifact.

You do not need Flutter installed on your phone for this cloud build.
